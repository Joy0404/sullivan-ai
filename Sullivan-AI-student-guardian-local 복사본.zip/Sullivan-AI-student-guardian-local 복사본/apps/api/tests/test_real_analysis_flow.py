"""Exercise API routes through real adapters; only Google's HTTP boundary is simulated."""
import json
import httpx
import pytest
from fastapi.testclient import TestClient
import app.adapters.video_link as adapter
from app.main import app

PACKAGE = {
 'transcript_segments':[{'segment_id':'s1','start_ms':0,'end_ms':2000,'text':'실험 영상의 발화입니다.','confidence':0.95}],
 'visual_observations':[{'observation_id':'v1','timestamp_ms':1000,'screen_type':'slide','kind':'concept','text':'테스트 슬라이드','confidence':0.95,'importance':0.9,'metadata':{'verification':'confirmed','visible_evidence':['테스트 슬라이드']}}],
}
@pytest.fixture
def service(monkeypatch):
 monkeypatch.setenv('GEMINI_API_KEY','fake-provider-key')
 monkeypatch.setenv('DEMO_ACCESS_CODE','test-code')
 monkeypatch.delenv('RESTRICT_SAMPLE_LINKS',raising=False)
 monkeypatch.delenv('LINK_ANALYZER_URL',raising=False)
 return TestClient(app)

def session(c):
 return c.post('/v1/lectures',json={'title':'실제 경로 검사','subject':'과학','source_label':'test','preferred_mode':'auto','problem_mode':False}).json()['session_id']

def network(monkeypatch, status=200, empty=False, delete_status=200):
 calls=[]
 def handle(req):
  calls.append(req)
  if 'upload/v1beta/files' in req.url.path:
   return httpx.Response(200,headers={'x-goog-upload-url':'https://generativelanguage.googleapis.com/resumable/test'})
  if req.url.path=='/resumable/test':
   return httpx.Response(200,json={'file':{'name':'files/test','uri':'https://generativelanguage.googleapis.com/v1beta/files/test','state':'PROCESSING'}})
  if req.method=='GET':
   return httpx.Response(200,json={'name':'files/test','uri':'https://generativelanguage.googleapis.com/v1beta/files/test','state':'ACTIVE'})
  if req.method=='DELETE':return httpx.Response(delete_status,json={})
  assert ':generateContent' in req.url.path, 'No hidden fallback/repeated billing'
  if status!=200:return httpx.Response(status,json={'error':{'message':'quota failed'}})
  text=json.dumps({} if empty else PACKAGE,ensure_ascii=False)
  return httpx.Response(200,json={'candidates':[{'finishReason':'STOP','content':{'parts':[{'text':text[:12]},{'text':text[12:]}]}}]})
 real=httpx.AsyncClient
 monkeypatch.setattr(adapter.httpx,'AsyncClient',lambda **kw:real(transport=httpx.MockTransport(handle)))
 async def no_sleep(_):pass
 monkeypatch.setattr(adapter.asyncio,'sleep',no_sleep)
 return calls

@pytest.mark.parametrize('url',['https://youtu.be/dQw4w9WgXcQ','https://media.example.com/lecture.webm'])
def test_general_links_reach_two_pass_gemini(service,monkeypatch,url):
 calls=network(monkeypatch)
 r=service.post(f'/v1/lectures/{session(service)}/video-link',json={'url':url,'rights_confirmed':True,'analysis_consent':True,'request_analysis':True,'access_code':'test-code'})
 assert r.status_code==200,r.text
 assert r.json()['analysis_status']=='completed'
 assert len(calls)==2
 assert json.loads(calls[0].content)['contents'][0]['parts'][0]['file_data']['file_uri']==url
 assert '실험 영상의 발화' in r.text

@pytest.mark.parametrize(('status','empty','delete_status','expected'),[(200,False,200,200),(429,False,200,502),(200,True,200,502),(200,False,500,502)])
def test_file_route_upload_poll_two_pass_and_cleanup(service,monkeypatch,status,empty,delete_status,expected):
 calls=network(monkeypatch,status,empty,delete_status)
 sid=session(service)
 service.post(f'/v1/lectures/{sid}/assets',json={'asset_id':'video-real','name':'own.mp4','kind':'video','media_type':'video/mp4'})
 r=service.post(f'/v1/lectures/{sid}/video-file-analysis',data={'asset_id':'video-real','rights_confirmed':'true','cloud_analysis_consent':'true','access_code':'test-code'},files={'video':('own.mp4',b'synthetic-video-bytes','video/mp4')})
 assert r.status_code==expected,r.text
 assert calls[-1].method=='DELETE'
 assert len([x for x in calls if ':generateContent' in x.url.path])==(1 if status!=200 else 2)
 assert 'fake-provider-key' not in r.text
 if expected!=200:
  assert service.get(f'/v1/lectures/{sid}').json()['assets'][0]['processing_status']!='indexed'

def test_nonvideo_webpage_explains_supported_input(service,monkeypatch):
 calls=network(monkeypatch)
 r=service.post(f'/v1/lectures/{session(service)}/video-link',json={'url':'https://example.com/course','rights_confirmed':True,'analysis_consent':True,'access_code':'test-code'})
 assert r.status_code==400
 assert '영상 파일 자체' in r.json()['detail']
 assert not calls
