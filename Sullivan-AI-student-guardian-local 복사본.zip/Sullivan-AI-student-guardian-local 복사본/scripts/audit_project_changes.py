"""Read source only: inventory, syntax, and differences from an untouched original."""
import argparse,ast,hashlib,json,re
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
EXT={'.py','.js','.css','.html','.json'}
def inventory(root):
 result={}
 paths=[p for base in ['apps','packages','scripts'] for p in (root/base).rglob('*')]
 paths.append(root/'run_local.py')
 for p in paths:
   if not p.is_file() or p.suffix not in EXT or any(x in p.parts for x in ['__pycache__','node_modules','.venv','data']):continue
   text=p.read_text(encoding='utf-8');entry={'lines':len(text.splitlines()),'bytes':p.stat().st_size,'sha256':hashlib.sha256(text.encode()).hexdigest()}
   if p.suffix=='.py':
    tree=ast.parse(text,filename=str(p));entry['functions']=sum(isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) for n in ast.walk(tree))
   elif p.suffix=='.js':entry['functions']=len(re.findall(r'^(?:async )?function ',text,re.M))
   elif p.suffix=='.json':json.loads(text)
   result[str(p.relative_to(root))]=entry
 return result
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--original',type=Path,required=True);args=parser.parse_args()
 old,new=inventory(args.original),inventory(ROOT)
 changes={kind:[] for kind in ['added','modified','removed']}
 for path in sorted(old.keys()|new.keys()):
  if path not in old:changes['added'].append(path)
  elif path not in new:changes['removed'].append(path)
  elif old[path]['sha256']!=new[path]['sha256']:changes['modified'].append(path)
 result={'scope':'All apps/packages/scripts source files and run_local.py; no credentials, account rows or original edits','original':str(args.original),'source_files':len(new),'source_by_extension':{ext:sum(Path(p).suffix==ext for p in new) for ext in sorted(EXT)},'changes':changes,'app_js_original_lines':old['apps/web/app.js']['lines'],'app_js_current_lines':new['apps/web/app.js']['lines'],'provider_adapters_unchanged':[p for p in new if p.startswith('apps/api/app/adapters/') and p in old and new[p]['sha256']==old[p]['sha256']],'inventory':new}
 target=ROOT/'docs/verification/code-review-results.json';target.write_text(json.dumps(result,ensure_ascii=False,indent=2))
 print(json.dumps({k:v for k,v in result.items() if k not in ['inventory','changes','original']},ensure_ascii=False))
 print('변경 파일 수:',{k:len(v) for k,v in changes.items()})
if __name__=='__main__':main()
