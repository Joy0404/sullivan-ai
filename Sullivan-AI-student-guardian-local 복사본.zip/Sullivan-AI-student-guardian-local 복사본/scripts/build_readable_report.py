"""Optional report tool; run with a reportlab-equipped development Python."""
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SECTIONS=[
 ('Sullivan AI<br/>학생·보호자용 개선 보고서',[
  ('p','학생은 준비된 강의를 바로 듣고, 보호자는 자료와 배정을 관리합니다.'),
  ('h2','학생이 직접 하는 네 가지'),
  ('p','강의 듣기: 재생·이어 듣기·10초 이동·화면 해설'),
  ('p','지문·문단 듣기: 문단 이동·밑줄·선택 낭독'),
  ('p','원하는 내용 찾기: 검색·강사 구간 재생·원래 위치 복귀'),
  ('p','질문하기: 강의 근거에 따른 질문·요약·추가 설명'),
  ('h2','보호자가 준비하는 일'),
  ('p','학생 연결, 영상·자료 등록, 동의와 분석, 강의 배정·순서·삭제를 관리합니다.'),
  ('p','학습 위치와 기록은 자동 저장을 우선합니다. 학생은 읽기 속도와 음량을 직접 조절합니다.')]),
 ('원본과 달라진 점',[
  ('h2','수정'),
  ('p','공통 화면을 학생 학습 화면과 보호자 준비실로 나눴습니다.'),
  ('p','학생·보호자 로그인 선택, 앱 음성, 키보드 포커스와 오류 안내를 개선했습니다.'),
  ('h2','통합'),
  ('p','복습·노트·북마크·메모는 학습 기록으로 연결했습니다.'),
  ('p','개념·키워드·강의 흐름 검색과 구간 재생은 원하는 내용 찾기로 모았습니다.'),
  ('h2','제외하거나 옮긴 것'),
  ('p','업로드·동의·코드·기술 정보·삭제 관리는 보호자에게 옮겼습니다.'),
  ('p','중복 전역 Space 처리와 옛 자유 모드 전환은 제거하고, 빠른 명령 영역 하나를 사용합니다.'),
  ('p','자동 해설·지문 낭독·학습 질문·샘플 기능은 유지했습니다.')]),
 ('샘플 배정 오류를 다시 고친 방법',[
  ('h2','확인한 사실'),
  ('p','기존 계정은 있었지만, 이 작업본의 강의와 배정 저장 기록은 0건이었습니다.'),
  ('p','제출 버튼 정보가 없는 폼 전송에서 저장 전에 멈추는 코드 결함을 수정했습니다.'),
  ('h2','이제는 한 화면에서 배정합니다'),
  ('p','1. 보호자 준비실의 샘플 바로 배정을 이용합니다.'),
  ('p','2. 학생과 과학·역사 샘플을 고릅니다.'),
  ('p','3. 선택한 학생에게 샘플 배정을 누릅니다.'),
  ('p','서버가 배정과 준비 완료를 함께 저장합니다. 미리보기만 여는 것은 배정이 아닙니다.'),
  ('p','이전 실패 당시 화면·요청 로그는 확보하지 못했습니다. 새 경로는 별도 계정과 실제 서버 재시작으로 검증했습니다.')]),
 ('코드 정리·검증·실행',[
  ('h2','불필요한 경로 정리'),
  ('p','중복 Space·음성 처리 603줄을 정리했습니다. app.js는 원본 2,735줄에서 2,202줄이 됐습니다.'),
  ('p','샘플을 공통 JSON으로 모으고, 강의 목록의 반복 쿼리와 불필요한 정보 읽기를 줄였습니다.'),
  ('h2','검증 결과'),
  ('p','113개 통과·4개 제외. 32개 화면·상태의 자동 접근성 검사 위반 0건입니다.'),
  ('p','두 샘플은 실제 서버 재시작 후에도 유지됐습니다. 저장 실패를 성공으로 표시하지 않습니다.'),
  ('h2','수정본 실행'),
  ('p','http://127.0.0.1:8770<br/>화면 상단의 학생·보호자 로컬 r2를 확인하세요. 현재 샘플 모드입니다.'),
  ('p','실제 스크린리더·마이크·Gemini·YouTube 연결은 미검증입니다.'),
  ('p','원본·계정과 Gemini 모델·API 설정, 동의·개인정보·정답 보호 정책은 유지했습니다.')])
]

def build_html():
 sheets=[]
 for i,(title,blocks) in enumerate(SECTIONS,1):
  content=''.join(f'<{tag}>{text}</{tag}>' for tag,text in blocks)
  sheets.append(f'<section class="sheet" aria-labelledby="section-{i}"><h1 id="section-{i}">{title}</h1>{content}</section>')
 html='''<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Sullivan AI 개선 보고서 - 큰 글씨</title><style>
*{box-sizing:border-box}body{margin:0;background:#edf2f7;color:#172c48;font:22px/1.7 "Apple SD Gothic Neo","Malgun Gothic",sans-serif;word-break:keep-all;overflow-wrap:anywhere}.sheet{max-width:900px;margin:28px auto;padding:44px;background:white;border:1px solid #b7c6d7;border-radius:12px}h1{font-size:38px;line-height:1.35;margin:0 0 30px}h2{font-size:29px;line-height:1.4;margin:30px 0 12px;color:#164b8b}p{margin:0 0 18px}header{max-width:900px;margin:30px auto 0;padding:0 24px}header p{font-size:22px}a{color:#164b8b}a:focus-visible{outline:4px solid #8c4700;outline-offset:4px}@media(max-width:600px){.sheet{margin:16px 12px;padding:26px 22px}h1{font-size:32px}h2{font-size:26px}}@media print{body{background:white}.sheet{border:0;page-break-before:always;padding:0;margin:0;max-width:none}header{display:none}}
</style></head><body><header><p>2026년 11월 2일 작성 · 큰 글씨 읽기용 보고서</p><p><a href="../output/pdf/Sullivan_AI_학생_보호자_개선_보고서.pdf">인쇄용 PDF 열기</a></p></header><main>'''+''.join(sheets)+'''</main></body></html>'''
 target=ROOT/'docs/Sullivan_AI_개선_보고서_큰글씨.html';target.write_text(html,encoding='utf-8');return target

def build_pdf():
 from reportlab.lib import colors
 from reportlab.lib.enums import TA_LEFT
 from reportlab.lib.pagesizes import A4
 from reportlab.lib.styles import ParagraphStyle
 from reportlab.lib.units import mm
 from reportlab.pdfbase import pdfmetrics
 from reportlab.pdfbase.ttfonts import TTFont
 from reportlab.platypus import SimpleDocTemplate,Paragraph,PageBreak
 pdfmetrics.registerFont(TTFont('ReportKorean','/System/Library/Fonts/Supplemental/AppleGothic.ttf'))
 styles={
  'title':ParagraphStyle('title',fontName='ReportKorean',fontSize=28,leading=36,textColor=colors.HexColor('#172c48'),spaceAfter=22,wordWrap='CJK',alignment=TA_LEFT),
  'h2':ParagraphStyle('h2',fontName='ReportKorean',fontSize=21,leading=29,textColor=colors.HexColor('#164b8b'),spaceBefore=13,spaceAfter=8,wordWrap='CJK'),
  'p':ParagraphStyle('p',fontName='ReportKorean',fontSize=18,leading=26,textColor=colors.HexColor('#172c48'),spaceAfter=10,wordWrap='CJK')}
 target=ROOT/'output/pdf/Sullivan_AI_학생_보호자_개선_보고서.pdf';target.parent.mkdir(parents=True,exist_ok=True)
 doc=SimpleDocTemplate(str(target),pagesize=A4,rightMargin=18*mm,leftMargin=18*mm,topMargin=18*mm,bottomMargin=20*mm,title='Sullivan AI 학생·보호자용 개선 보고서',author='Sullivan AI 로컬 작업본')
 story=[]
 for i,(title,blocks) in enumerate(SECTIONS):
  if i:story.append(PageBreak())
  story.append(Paragraph(title,styles['title']))
  for tag,text in blocks:story.append(Paragraph(text,styles[tag]))
 def footer(canvas,document):
  canvas.saveState();canvas.setFont('ReportKorean',14);canvas.setFillColor(colors.HexColor('#465c73'));canvas.drawString(18*mm,11*mm,'2026.11.02  Sullivan AI');canvas.drawRightString(A4[0]-18*mm,11*mm,str(document.page));canvas.restoreState()
 doc.build(story,onFirstPage=footer,onLaterPages=footer)
 return target

if __name__=='__main__':
 print(build_html());print(build_pdf())
